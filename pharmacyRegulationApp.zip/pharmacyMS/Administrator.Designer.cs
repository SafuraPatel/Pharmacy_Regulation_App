﻿namespace pharmacyMS
{
    partial class Administrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Administrator));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.userNameLable = new System.Windows.Forms.Label();
            this.btnlogout = new Guna.UI.WinForms.GunaButton();
            this.btnProfile = new Guna.UI.WinForms.GunaButton();
            this.btnViewUser = new Guna.UI.WinForms.GunaButton();
            this.btnadduser = new Guna.UI.WinForms.GunaButton();
            this.btndashboard = new Guna.UI.WinForms.GunaButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse2 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse3 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse4 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.uC_Profile1 = new pharmacyMS.AdministratorUC.UC_Profile();
            this.uC_ViewUser1 = new pharmacyMS.AdministratorUC.UC_ViewUser();
            this.uC_Adduser1 = new pharmacyMS.AdministratorUC.UC_Adduser();
            this.uC_Dashboard1 = new pharmacyMS.AdministratorUC.UC_Dashboard();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.userNameLable);
            this.panel1.Controls.Add(this.btnlogout);
            this.panel1.Controls.Add(this.btnProfile);
            this.panel1.Controls.Add(this.btnViewUser);
            this.panel1.Controls.Add(this.btnadduser);
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(372, 903);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(46, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(280, 224);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // userNameLable
            // 
            this.userNameLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameLable.ForeColor = System.Drawing.Color.SteelBlue;
            this.userNameLable.Location = new System.Drawing.Point(-3, 831);
            this.userNameLable.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userNameLable.Name = "userNameLable";
            this.userNameLable.Size = new System.Drawing.Size(378, 54);
            this.userNameLable.TabIndex = 9;
            this.userNameLable.Text = "SS Health Care";
            this.userNameLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnlogout
            // 
            this.btnlogout.AnimationHoverSpeed = 0.07F;
            this.btnlogout.AnimationSpeed = 0.03F;
            this.btnlogout.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnlogout.BorderColor = System.Drawing.Color.Black;
            this.btnlogout.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnlogout.FocusedColor = System.Drawing.Color.Empty;
            this.btnlogout.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.White;
            this.btnlogout.Image = ((System.Drawing.Image)(resources.GetObject("btnlogout.Image")));
            this.btnlogout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnlogout.ImageSize = new System.Drawing.Size(30, 30);
            this.btnlogout.Location = new System.Drawing.Point(0, 681);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.OnHoverBaseColor = System.Drawing.Color.DimGray;
            this.btnlogout.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnlogout.OnHoverForeColor = System.Drawing.Color.White;
            this.btnlogout.OnHoverImage = null;
            this.btnlogout.OnPressedColor = System.Drawing.Color.Black;
            this.btnlogout.Size = new System.Drawing.Size(375, 59);
            this.btnlogout.TabIndex = 6;
            this.btnlogout.Text = "Logout";
            this.btnlogout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.AnimationHoverSpeed = 0.07F;
            this.btnProfile.AnimationSpeed = 0.03F;
            this.btnProfile.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnProfile.BorderColor = System.Drawing.Color.Black;
            this.btnProfile.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnProfile.FocusedColor = System.Drawing.Color.Empty;
            this.btnProfile.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.White;
            this.btnProfile.Image = ((System.Drawing.Image)(resources.GetObject("btnProfile.Image")));
            this.btnProfile.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnProfile.ImageSize = new System.Drawing.Size(30, 30);
            this.btnProfile.Location = new System.Drawing.Point(-3, 592);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.OnHoverBaseColor = System.Drawing.Color.DimGray;
            this.btnProfile.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnProfile.OnHoverForeColor = System.Drawing.Color.White;
            this.btnProfile.OnHoverImage = null;
            this.btnProfile.OnPressedColor = System.Drawing.Color.Black;
            this.btnProfile.Size = new System.Drawing.Size(375, 59);
            this.btnProfile.TabIndex = 5;
            this.btnProfile.Text = "Profile";
            this.btnProfile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnViewUser
            // 
            this.btnViewUser.AnimationHoverSpeed = 0.07F;
            this.btnViewUser.AnimationSpeed = 0.03F;
            this.btnViewUser.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnViewUser.BorderColor = System.Drawing.Color.Black;
            this.btnViewUser.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnViewUser.FocusedColor = System.Drawing.Color.Empty;
            this.btnViewUser.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewUser.ForeColor = System.Drawing.Color.White;
            this.btnViewUser.Image = ((System.Drawing.Image)(resources.GetObject("btnViewUser.Image")));
            this.btnViewUser.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnViewUser.ImageSize = new System.Drawing.Size(35, 35);
            this.btnViewUser.Location = new System.Drawing.Point(0, 504);
            this.btnViewUser.Name = "btnViewUser";
            this.btnViewUser.OnHoverBaseColor = System.Drawing.Color.DimGray;
            this.btnViewUser.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnViewUser.OnHoverForeColor = System.Drawing.Color.White;
            this.btnViewUser.OnHoverImage = null;
            this.btnViewUser.OnPressedColor = System.Drawing.Color.Black;
            this.btnViewUser.Size = new System.Drawing.Size(372, 59);
            this.btnViewUser.TabIndex = 4;
            this.btnViewUser.Text = "View User";
            this.btnViewUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnViewUser.Click += new System.EventHandler(this.btnViewUser_Click);
            // 
            // btnadduser
            // 
            this.btnadduser.AnimationHoverSpeed = 0.07F;
            this.btnadduser.AnimationSpeed = 0.03F;
            this.btnadduser.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnadduser.BorderColor = System.Drawing.Color.Black;
            this.btnadduser.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnadduser.FocusedColor = System.Drawing.Color.Empty;
            this.btnadduser.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadduser.ForeColor = System.Drawing.Color.White;
            this.btnadduser.Image = ((System.Drawing.Image)(resources.GetObject("btnadduser.Image")));
            this.btnadduser.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnadduser.ImageSize = new System.Drawing.Size(30, 30);
            this.btnadduser.Location = new System.Drawing.Point(-10, 415);
            this.btnadduser.Name = "btnadduser";
            this.btnadduser.OnHoverBaseColor = System.Drawing.Color.DimGray;
            this.btnadduser.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnadduser.OnHoverForeColor = System.Drawing.Color.White;
            this.btnadduser.OnHoverImage = null;
            this.btnadduser.OnPressedColor = System.Drawing.Color.Black;
            this.btnadduser.Size = new System.Drawing.Size(385, 59);
            this.btnadduser.TabIndex = 3;
            this.btnadduser.Text = "Add User";
            this.btnadduser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnadduser.Click += new System.EventHandler(this.btnadduser_Click);
            // 
            // btndashboard
            // 
            this.btndashboard.AnimationHoverSpeed = 0.07F;
            this.btndashboard.AnimationSpeed = 0.03F;
            this.btndashboard.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btndashboard.BorderColor = System.Drawing.Color.Black;
            this.btndashboard.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btndashboard.FocusedColor = System.Drawing.Color.Empty;
            this.btndashboard.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.ForeColor = System.Drawing.Color.White;
            this.btndashboard.Image = ((System.Drawing.Image)(resources.GetObject("btndashboard.Image")));
            this.btndashboard.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btndashboard.ImageSize = new System.Drawing.Size(30, 30);
            this.btndashboard.Location = new System.Drawing.Point(0, 331);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.OnHoverBaseColor = System.Drawing.Color.DimGray;
            this.btndashboard.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btndashboard.OnHoverForeColor = System.Drawing.Color.White;
            this.btndashboard.OnHoverImage = null;
            this.btndashboard.OnPressedColor = System.Drawing.Color.Black;
            this.btndashboard.Size = new System.Drawing.Size(375, 59);
            this.btndashboard.TabIndex = 2;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(89, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Administrator";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.uC_Profile1);
            this.panel2.Controls.Add(this.uC_ViewUser1);
            this.panel2.Controls.Add(this.uC_Adduser1);
            this.panel2.Controls.Add(this.uC_Dashboard1);
            this.panel2.Location = new System.Drawing.Point(375, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1120, 901);
            this.panel2.TabIndex = 1;
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.TargetControl = this.panel2;
            // 
            // gunaElipse2
            // 
            this.gunaElipse2.TargetControl = this.panel2;
            // 
            // gunaElipse3
            // 
            this.gunaElipse3.TargetControl = this.panel2;
            // 
            // gunaElipse4
            // 
            this.gunaElipse4.TargetControl = this.panel2;
            // 
            // uC_Profile1
            // 
            this.uC_Profile1.BackColor = System.Drawing.Color.White;
            this.uC_Profile1.Location = new System.Drawing.Point(0, 0);
            this.uC_Profile1.Name = "uC_Profile1";
            this.uC_Profile1.Size = new System.Drawing.Size(1120, 901);
            this.uC_Profile1.TabIndex = 3;
            // 
            // uC_ViewUser1
            // 
            this.uC_ViewUser1.BackColor = System.Drawing.Color.White;
            this.uC_ViewUser1.Location = new System.Drawing.Point(0, 0);
            this.uC_ViewUser1.Name = "uC_ViewUser1";
            this.uC_ViewUser1.Size = new System.Drawing.Size(1120, 901);
            this.uC_ViewUser1.TabIndex = 2;
            // 
            // uC_Adduser1
            // 
            this.uC_Adduser1.BackColor = System.Drawing.Color.White;
            this.uC_Adduser1.Location = new System.Drawing.Point(0, -2);
            this.uC_Adduser1.Margin = new System.Windows.Forms.Padding(0);
            this.uC_Adduser1.Name = "uC_Adduser1";
            this.uC_Adduser1.Size = new System.Drawing.Size(1120, 901);
            this.uC_Adduser1.TabIndex = 1;
            // 
            // uC_Dashboard1
            // 
            this.uC_Dashboard1.BackColor = System.Drawing.Color.White;
            this.uC_Dashboard1.Location = new System.Drawing.Point(0, 0);
            this.uC_Dashboard1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.uC_Dashboard1.Name = "uC_Dashboard1";
            this.uC_Dashboard1.Size = new System.Drawing.Size(1120, 901);
            this.uC_Dashboard1.TabIndex = 0;
            // 
            // Administrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1496, 904);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Administrator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administrator";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton btnlogout;
        private Guna.UI.WinForms.GunaButton btnProfile;
        private Guna.UI.WinForms.GunaButton btnViewUser;
        private Guna.UI.WinForms.GunaButton btnadduser;
        private Guna.UI.WinForms.GunaButton btndashboard;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private AdministratorUC.UC_Dashboard uC_Dashboard1;
        private Guna.UI.WinForms.GunaElipse gunaElipse2;
        private AdministratorUC.UC_Adduser uC_Adduser1;
        private System.Windows.Forms.Label userNameLable;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AdministratorUC.UC_ViewUser uC_ViewUser1;
        private AdministratorUC.UC_Profile uC_Profile1;
        private Guna.UI.WinForms.GunaElipse gunaElipse3;
        private Guna.UI.WinForms.GunaElipse gunaElipse4;
    }
}