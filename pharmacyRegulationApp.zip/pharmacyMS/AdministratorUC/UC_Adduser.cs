﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacyMS.AdministratorUC
{

    public partial class UC_Adduser : UserControl
    {

        function fn = new function();
        String query;


        public UC_Adduser()
        {
            InitializeComponent();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string role = txtUserRole.Text;
            string name = txtName.Text;
            string dob = txtDob.Text;
            Int64 mobile = Int64.Parse(txtMobileNo.Text);
            string email = txtEmail.Text;
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            try
            {
                query = "insert into users (userrole,uname,dob,mobile,email,username,pass) values ('"+role+"','"+name+"','"+dob+ "','"+mobile+ "','"+email+ "','"+username+ "','"+password+"')";
                fn.setData(query, "Sign Up Successfull");
          
            }
            catch (Exception)
            {
                MessageBox.Show("Username already exist.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        public void clearAll()
        {
            txtName.Clear();
            txtDob.ResetText();
            txtMobileNo.Clear();
            txtEmail.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            txtUserRole.SelectedIndex = -1;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        private void txtUsername_TextChanged(object sender, EventArgs e) { }
       
    }
}
