﻿namespace pharmacyMS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtusername = new Guna.UI.WinForms.GunaTextBox();
            this.txtpassword = new Guna.UI.WinForms.GunaTextBox();
            this.txtsignin = new Guna.UI.WinForms.GunaButton();
            this.txtreset = new Guna.UI.WinForms.GunaButton();
            this.label6 = new System.Windows.Forms.Label();
            this.btnExist = new Guna.UI.WinForms.GunaButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 905);
            this.panel1.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MistyRose;
            this.label5.Location = new System.Drawing.Point(198, 759);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(233, 36);
            this.label5.TabIndex = 8;
            this.label5.Text = "SS Health Care";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(94, 243);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(449, 410);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(147, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(360, 146);
            this.label1.TabIndex = 0;
            this.label1.Text = "  Pharmacy\r\nRegulations   ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(777, 209);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 670);
            this.panel2.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1031, 373);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 33);
            this.label4.TabIndex = 14;
            this.label4.Text = "  Sign in  ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(903, 583);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 33);
            this.label3.TabIndex = 13;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(903, 491);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 33);
            this.label2.TabIndex = 12;
            this.label2.Text = "User name ";
            // 
            // txtusername
            // 
            this.txtusername.BackColor = System.Drawing.Color.Transparent;
            this.txtusername.BaseColor = System.Drawing.Color.White;
            this.txtusername.BorderColor = System.Drawing.Color.DarkGray;
            this.txtusername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtusername.FocusedBaseColor = System.Drawing.Color.White;
            this.txtusername.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtusername.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtusername.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.ForeColor = System.Drawing.Color.Black;
            this.txtusername.Location = new System.Drawing.Point(1101, 481);
            this.txtusername.Name = "txtusername";
            this.txtusername.PasswordChar = '\0';
            this.txtusername.Radius = 5;
            this.txtusername.SelectedText = "";
            this.txtusername.Size = new System.Drawing.Size(261, 43);
            this.txtusername.TabIndex = 15;
            this.txtusername.TextChanged += new System.EventHandler(this.txtusername_TextChanged);
            // 
            // txtpassword
            // 
            this.txtpassword.BackColor = System.Drawing.Color.Transparent;
            this.txtpassword.BaseColor = System.Drawing.Color.White;
            this.txtpassword.BorderColor = System.Drawing.Color.DarkGray;
            this.txtpassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtpassword.FocusedBaseColor = System.Drawing.Color.White;
            this.txtpassword.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtpassword.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtpassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.ForeColor = System.Drawing.Color.Black;
            this.txtpassword.Location = new System.Drawing.Point(1101, 573);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            this.txtpassword.Radius = 5;
            this.txtpassword.SelectedText = "";
            this.txtpassword.Size = new System.Drawing.Size(261, 43);
            this.txtpassword.TabIndex = 16;
            // 
            // txtsignin
            // 
            this.txtsignin.AnimationHoverSpeed = 0.07F;
            this.txtsignin.AnimationSpeed = 0.03F;
            this.txtsignin.BackColor = System.Drawing.Color.Transparent;
            this.txtsignin.BaseColor = System.Drawing.Color.DarkBlue;
            this.txtsignin.BorderColor = System.Drawing.Color.MidnightBlue;
            this.txtsignin.BorderSize = 2;
            this.txtsignin.DialogResult = System.Windows.Forms.DialogResult.None;
            this.txtsignin.FocusedColor = System.Drawing.Color.Empty;
            this.txtsignin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsignin.ForeColor = System.Drawing.Color.White;
            this.txtsignin.Image = ((System.Drawing.Image)(resources.GetObject("txtsignin.Image")));
            this.txtsignin.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtsignin.ImageSize = new System.Drawing.Size(40, 40);
            this.txtsignin.Location = new System.Drawing.Point(889, 688);
            this.txtsignin.Name = "txtsignin";
            this.txtsignin.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtsignin.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.txtsignin.OnHoverForeColor = System.Drawing.Color.Navy;
            this.txtsignin.OnHoverImage = null;
            this.txtsignin.OnPressedColor = System.Drawing.Color.Black;
            this.txtsignin.Radius = 3;
            this.txtsignin.Size = new System.Drawing.Size(192, 66);
            this.txtsignin.TabIndex = 20;
            this.txtsignin.Text = "Sign In";
            this.txtsignin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtsignin.Click += new System.EventHandler(this.txtsignin_Click);
            // 
            // txtreset
            // 
            this.txtreset.AnimationHoverSpeed = 0.07F;
            this.txtreset.AnimationSpeed = 0.03F;
            this.txtreset.BackColor = System.Drawing.Color.Transparent;
            this.txtreset.BaseColor = System.Drawing.Color.DarkBlue;
            this.txtreset.BorderColor = System.Drawing.Color.MidnightBlue;
            this.txtreset.BorderSize = 2;
            this.txtreset.DialogResult = System.Windows.Forms.DialogResult.None;
            this.txtreset.FocusedColor = System.Drawing.Color.Empty;
            this.txtreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreset.ForeColor = System.Drawing.Color.White;
            this.txtreset.Image = ((System.Drawing.Image)(resources.GetObject("txtreset.Image")));
            this.txtreset.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtreset.ImageSize = new System.Drawing.Size(30, 30);
            this.txtreset.Location = new System.Drawing.Point(1170, 688);
            this.txtreset.Name = "txtreset";
            this.txtreset.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtreset.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.txtreset.OnHoverForeColor = System.Drawing.Color.Navy;
            this.txtreset.OnHoverImage = null;
            this.txtreset.OnPressedColor = System.Drawing.Color.Black;
            this.txtreset.Radius = 3;
            this.txtreset.Size = new System.Drawing.Size(192, 66);
            this.txtreset.TabIndex = 22;
            this.txtreset.Text = "Reset";
            this.txtreset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtreset.Click += new System.EventHandler(this.txtreset_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(844, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(476, 33);
            this.label6.TabIndex = 23;
            this.label6.Text = "Welcome To SS Health Care";
            // 
            // btnExist
            // 
            this.btnExist.AnimationHoverSpeed = 0.07F;
            this.btnExist.AnimationSpeed = 0.03F;
            this.btnExist.BaseColor = System.Drawing.Color.White;
            this.btnExist.BorderColor = System.Drawing.Color.Black;
            this.btnExist.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnExist.FocusedColor = System.Drawing.Color.Empty;
            this.btnExist.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnExist.ForeColor = System.Drawing.Color.White;
            this.btnExist.Image = ((System.Drawing.Image)(resources.GetObject("btnExist.Image")));
            this.btnExist.ImageSize = new System.Drawing.Size(35, 35);
            this.btnExist.Location = new System.Drawing.Point(1396, 12);
            this.btnExist.Name = "btnExist";
            this.btnExist.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnExist.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnExist.OnHoverForeColor = System.Drawing.Color.White;
            this.btnExist.OnHoverImage = null;
            this.btnExist.OnPressedColor = System.Drawing.Color.Black;
            this.btnExist.Size = new System.Drawing.Size(72, 48);
            this.btnExist.TabIndex = 24;
            this.btnExist.Click += new System.EventHandler(this.btnExist_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(909, 124);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(390, 246);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1492, 904);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnExist);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtreset);
            this.Controls.Add(this.txtsignin);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.TopMost = true;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Guna.UI.WinForms.GunaTextBox txtusername;
        private Guna.UI.WinForms.GunaTextBox txtpassword;
        private Guna.UI.WinForms.GunaButton txtsignin;
        private Guna.UI.WinForms.GunaButton txtreset;
        private System.Windows.Forms.Label label6;
        private Guna.UI.WinForms.GunaButton btnExist;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

