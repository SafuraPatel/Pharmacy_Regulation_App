﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Xml.Linq;

namespace pharmacyMS.PharmacistUC
{
    public partial class UC_P_AddMedicine : UserControl
    {
        function fn = new function();
        string query;

        public UC_P_AddMedicine()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtMedid.Text != "" && txtMedName.Text != "" && txtMedNum.Text != "" && txtQantity.Text != "" && txtPricePerUnit.Text != "")
            {
                string mid = txtMedid.Text;
                string mname = txtMedName.Text;
                string enumber = txtMedNum.Text;
                string mdate = txtManufacturingDate.Text;
                string edate = txtExpiryDate.Text;
                Int64 quantity = Int64.Parse(txtQantity.Text);
                Int64 perunit = Int64.Parse(txtPricePerUnit.Text);
                query = "insert into med (mid ,mname ,mnumber ,mdate ,edate ,quantity ,parunit) values ('" + mid + "','" + mname + "','" + enumber + "','" + mdate + "','" + edate + "','" + quantity + "','" + perunit + "')";
                fn.setData(query, "Medicine Added.");
            }
            else
            {
                MessageBox.Show("Enter all Date.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void clearAll()
        {
            txtMedid.Clear();
            txtMedName.Clear();
            txtQantity.Clear();
            txtMedNum.Clear();
            txtPricePerUnit.Clear();
            txtManufacturingDate.ResetText();
            txtExpiryDate.ResetText();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            clearAll();
        }
    }
}
