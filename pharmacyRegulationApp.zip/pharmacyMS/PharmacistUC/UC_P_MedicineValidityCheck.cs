﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacyMS.PharmacistUC
{
    public partial class UC_P_MedicineValidityCheck : UserControl
    {
        function fn = new function();
        string query;

        public UC_P_MedicineValidityCheck()
        {
            InitializeComponent();
        }

        private string getdate()
        {
            String s = DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year;
            return s;
        }


        private void txtCheck_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtCheck.SelectedIndex == 0)
            {
                query = "select * from med where edate <= '2023-03-29'";
                setDataGrdeView(query, "Valid Medicines", Color.Blue);
            }
            else if (txtCheck.SelectedIndex == 1)
            {
                query = "select mname from med where edate >= '2023-03-29'";
               
                setDataGrdeView(query, "Expired Medicines", Color.Red);
            }
            else if (txtCheck.SelectedIndex == 2)
            {
                query = "select * from med";
                setDataGrdeView(query, "All Medicines", Color.Black);
            }
        }

        private void setDataGrdeView(string query, string labelName,Color col)
        {
            DataSet ds = fn.geData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];
            setlable.Text = labelName;
            setlable.ForeColor = col;
        }

        private void UC_P_MedicineValidityCheck_Load(object sender, EventArgs e)
        {
            setlable.Text = "";
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        
    }
}
