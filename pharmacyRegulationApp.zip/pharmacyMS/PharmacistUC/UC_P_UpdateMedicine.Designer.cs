﻿namespace pharmacyMS.PharmacistUC
{
    partial class UC_P_UpdateMedicine
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_P_UpdateMedicine));
            this.label1 = new System.Windows.Forms.Label();
            this.txtEDate = new Guna.UI.WinForms.GunaDateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMedid = new Guna.UI.WinForms.GunaTextBox();
            this.btnReset = new Guna.UI.WinForms.GunaButton();
            this.btnUpdate = new Guna.UI.WinForms.GunaButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMDate = new Guna.UI.WinForms.GunaDateTimePicker();
            this.txtAvaibleQuantity = new Guna.UI.WinForms.GunaTextBox();
            this.txtMedNum = new Guna.UI.WinForms.GunaTextBox();
            this.txtMedName = new Guna.UI.WinForms.GunaTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSearch = new Guna.UI.WinForms.GunaButton();
            this.txtAddQuantity = new Guna.UI.WinForms.GunaTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPricePerUnit = new Guna.UI.WinForms.GunaTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Display", 24F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(307, 58);
            this.label1.TabIndex = 2;
            this.label1.Text = "Update Medicine";
            // 
            // txtEDate
            // 
            this.txtEDate.BackColor = System.Drawing.Color.Transparent;
            this.txtEDate.BaseColor = System.Drawing.Color.White;
            this.txtEDate.BorderColor = System.Drawing.Color.Silver;
            this.txtEDate.CustomFormat = null;
            this.txtEDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtEDate.FocusedColor = System.Drawing.Color.Gray;
            this.txtEDate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEDate.ForeColor = System.Drawing.Color.Black;
            this.txtEDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtEDate.Location = new System.Drawing.Point(627, 291);
            this.txtEDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtEDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtEDate.Name = "txtEDate";
            this.txtEDate.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtEDate.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.txtEDate.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEDate.OnPressedColor = System.Drawing.Color.Black;
            this.txtEDate.Radius = 5;
            this.txtEDate.Size = new System.Drawing.Size(402, 48);
            this.txtEDate.TabIndex = 55;
            this.txtEDate.Text = "28-09-2022";
            this.txtEDate.Value = new System.DateTime(2022, 9, 28, 20, 54, 42, 23);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(622, 259);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 26);
            this.label8.TabIndex = 54;
            this.label8.Text = "Expire Date";
            // 
            // txtMedid
            // 
            this.txtMedid.BackColor = System.Drawing.Color.Transparent;
            this.txtMedid.BaseColor = System.Drawing.Color.White;
            this.txtMedid.BorderColor = System.Drawing.Color.Silver;
            this.txtMedid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMedid.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMedid.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtMedid.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedid.Location = new System.Drawing.Point(90, 163);
            this.txtMedid.Name = "txtMedid";
            this.txtMedid.PasswordChar = '\0';
            this.txtMedid.Radius = 5;
            this.txtMedid.SelectedText = "";
            this.txtMedid.Size = new System.Drawing.Size(403, 48);
            this.txtMedid.TabIndex = 53;
            this.txtMedid.TextChanged += new System.EventHandler(this.txtMedid_TextChanged);
            // 
            // btnReset
            // 
            this.btnReset.AnimationHoverSpeed = 0.07F;
            this.btnReset.AnimationSpeed = 0.03F;
            this.btnReset.BackColor = System.Drawing.Color.Transparent;
            this.btnReset.BaseColor = System.Drawing.Color.MidnightBlue;
            this.btnReset.BorderColor = System.Drawing.Color.Navy;
            this.btnReset.BorderSize = 2;
            this.btnReset.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnReset.FocusedColor = System.Drawing.Color.Empty;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.Image = ((System.Drawing.Image)(resources.GetObject("btnReset.Image")));
            this.btnReset.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnReset.ImageSize = new System.Drawing.Size(20, 20);
            this.btnReset.Location = new System.Drawing.Point(866, 672);
            this.btnReset.Name = "btnReset";
            this.btnReset.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnReset.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.btnReset.OnHoverForeColor = System.Drawing.Color.Navy;
            this.btnReset.OnHoverImage = null;
            this.btnReset.OnPressedColor = System.Drawing.Color.Black;
            this.btnReset.Radius = 10;
            this.btnReset.Size = new System.Drawing.Size(176, 54);
            this.btnReset.TabIndex = 52;
            this.btnReset.Text = "Reset";
            this.btnReset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.AnimationHoverSpeed = 0.07F;
            this.btnUpdate.AnimationSpeed = 0.03F;
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.BaseColor = System.Drawing.Color.MidnightBlue;
            this.btnUpdate.BorderColor = System.Drawing.Color.Navy;
            this.btnUpdate.BorderSize = 2;
            this.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnUpdate.FocusedColor = System.Drawing.Color.Empty;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnUpdate.ImageSize = new System.Drawing.Size(30, 30);
            this.btnUpdate.Location = new System.Drawing.Point(651, 672);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnUpdate.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.btnUpdate.OnHoverForeColor = System.Drawing.Color.Navy;
            this.btnUpdate.OnHoverImage = null;
            this.btnUpdate.OnPressedColor = System.Drawing.Color.Black;
            this.btnUpdate.Radius = 10;
            this.btnUpdate.Size = new System.Drawing.Size(176, 54);
            this.btnUpdate.TabIndex = 51;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkBlue;
            this.panel2.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(566, 131);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 638);
            this.panel2.TabIndex = 50;
            // 
            // txtMDate
            // 
            this.txtMDate.BackColor = System.Drawing.Color.Transparent;
            this.txtMDate.BaseColor = System.Drawing.Color.White;
            this.txtMDate.BorderColor = System.Drawing.Color.Silver;
            this.txtMDate.CustomFormat = null;
            this.txtMDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtMDate.FocusedColor = System.Drawing.Color.Gray;
            this.txtMDate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMDate.ForeColor = System.Drawing.Color.Black;
            this.txtMDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtMDate.Location = new System.Drawing.Point(627, 160);
            this.txtMDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtMDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtMDate.Name = "txtMDate";
            this.txtMDate.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtMDate.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.txtMDate.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtMDate.OnPressedColor = System.Drawing.Color.Black;
            this.txtMDate.Radius = 5;
            this.txtMDate.Size = new System.Drawing.Size(402, 48);
            this.txtMDate.TabIndex = 49;
            this.txtMDate.Text = "28-09-2022";
            this.txtMDate.Value = new System.DateTime(2022, 9, 28, 20, 54, 42, 23);
            // 
            // txtAvaibleQuantity
            // 
            this.txtAvaibleQuantity.BackColor = System.Drawing.Color.Transparent;
            this.txtAvaibleQuantity.BaseColor = System.Drawing.Color.White;
            this.txtAvaibleQuantity.BorderColor = System.Drawing.Color.Silver;
            this.txtAvaibleQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAvaibleQuantity.FocusedBaseColor = System.Drawing.Color.White;
            this.txtAvaibleQuantity.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtAvaibleQuantity.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtAvaibleQuantity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAvaibleQuantity.Location = new System.Drawing.Point(627, 412);
            this.txtAvaibleQuantity.Name = "txtAvaibleQuantity";
            this.txtAvaibleQuantity.PasswordChar = '\0';
            this.txtAvaibleQuantity.Radius = 5;
            this.txtAvaibleQuantity.SelectedText = "";
            this.txtAvaibleQuantity.Size = new System.Drawing.Size(402, 48);
            this.txtAvaibleQuantity.TabIndex = 48;
            // 
            // txtMedNum
            // 
            this.txtMedNum.BackColor = System.Drawing.Color.Transparent;
            this.txtMedNum.BaseColor = System.Drawing.Color.White;
            this.txtMedNum.BorderColor = System.Drawing.Color.Silver;
            this.txtMedNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMedNum.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMedNum.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtMedNum.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedNum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedNum.Location = new System.Drawing.Point(93, 491);
            this.txtMedNum.Name = "txtMedNum";
            this.txtMedNum.PasswordChar = '\0';
            this.txtMedNum.Radius = 5;
            this.txtMedNum.SelectedText = "";
            this.txtMedNum.Size = new System.Drawing.Size(403, 48);
            this.txtMedNum.TabIndex = 47;
            // 
            // txtMedName
            // 
            this.txtMedName.BackColor = System.Drawing.Color.Transparent;
            this.txtMedName.BaseColor = System.Drawing.Color.White;
            this.txtMedName.BorderColor = System.Drawing.Color.Silver;
            this.txtMedName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMedName.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMedName.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtMedName.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedName.Location = new System.Drawing.Point(93, 370);
            this.txtMedName.Name = "txtMedName";
            this.txtMedName.PasswordChar = '\0';
            this.txtMedName.Radius = 5;
            this.txtMedName.SelectedText = "";
            this.txtMedName.Size = new System.Drawing.Size(403, 48);
            this.txtMedName.TabIndex = 46;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(622, 383);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(218, 26);
            this.label6.TabIndex = 45;
            this.label6.Text = "Avalible Quantity :-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(90, 462);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 26);
            this.label5.TabIndex = 44;
            this.label5.Text = "Medicine Number :-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(622, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 26);
            this.label4.TabIndex = 43;
            this.label4.Text = "Manufacturing Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(89, 341);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 26);
            this.label3.TabIndex = 42;
            this.label3.Text = "Medicine Name :-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(85, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 26);
            this.label2.TabIndex = 41;
            this.label2.Text = "Medicine ID :-";
            // 
            // btnSearch
            // 
            this.btnSearch.AnimationHoverSpeed = 0.07F;
            this.btnSearch.AnimationSpeed = 0.03F;
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.BaseColor = System.Drawing.Color.MidnightBlue;
            this.btnSearch.BorderColor = System.Drawing.Color.Navy;
            this.btnSearch.BorderSize = 2;
            this.btnSearch.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSearch.FocusedColor = System.Drawing.Color.Empty;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSearch.ImageSize = new System.Drawing.Size(30, 30);
            this.btnSearch.Location = new System.Drawing.Point(365, 217);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnSearch.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.btnSearch.OnHoverForeColor = System.Drawing.Color.Navy;
            this.btnSearch.OnHoverImage = null;
            this.btnSearch.OnPressedColor = System.Drawing.Color.Black;
            this.btnSearch.Radius = 20;
            this.btnSearch.Size = new System.Drawing.Size(176, 54);
            this.btnSearch.TabIndex = 58;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtAddQuantity
            // 
            this.txtAddQuantity.BackColor = System.Drawing.Color.Transparent;
            this.txtAddQuantity.BaseColor = System.Drawing.Color.White;
            this.txtAddQuantity.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.txtAddQuantity.BorderSize = 3;
            this.txtAddQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAddQuantity.FocusedBaseColor = System.Drawing.Color.White;
            this.txtAddQuantity.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtAddQuantity.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtAddQuantity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddQuantity.Location = new System.Drawing.Point(898, 466);
            this.txtAddQuantity.Name = "txtAddQuantity";
            this.txtAddQuantity.PasswordChar = '\0';
            this.txtAddQuantity.Radius = 5;
            this.txtAddQuantity.SelectedText = "";
            this.txtAddQuantity.Size = new System.Drawing.Size(115, 48);
            this.txtAddQuantity.TabIndex = 60;
            this.txtAddQuantity.Text = "0";
            this.txtAddQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(710, 481);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(167, 26);
            this.label9.TabIndex = 59;
            this.label9.Text = "Add Quantity:-";
            // 
            // txtPricePerUnit
            // 
            this.txtPricePerUnit.BackColor = System.Drawing.Color.Transparent;
            this.txtPricePerUnit.BaseColor = System.Drawing.Color.White;
            this.txtPricePerUnit.BorderColor = System.Drawing.Color.Silver;
            this.txtPricePerUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPricePerUnit.FocusedBaseColor = System.Drawing.Color.White;
            this.txtPricePerUnit.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtPricePerUnit.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtPricePerUnit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPricePerUnit.Location = new System.Drawing.Point(95, 638);
            this.txtPricePerUnit.Name = "txtPricePerUnit";
            this.txtPricePerUnit.PasswordChar = '\0';
            this.txtPricePerUnit.Radius = 5;
            this.txtPricePerUnit.SelectedText = "";
            this.txtPricePerUnit.Size = new System.Drawing.Size(402, 48);
            this.txtPricePerUnit.TabIndex = 62;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(90, 609);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(173, 26);
            this.label10.TabIndex = 61;
            this.label10.Text = "Price Per Unit:-";
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.TargetControl = this;
            // 
            // UC_P_UpdateMedicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtPricePerUnit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtAddQuantity);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtEDate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtMedid);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtMDate);
            this.Controls.Add(this.txtAvaibleQuantity);
            this.Controls.Add(this.txtMedNum);
            this.Controls.Add(this.txtMedName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UC_P_UpdateMedicine";
            this.Size = new System.Drawing.Size(1120, 901);
            this.Load += new System.EventHandler(this.UC_P_UpdateMedicine_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaDateTimePicker txtEDate;
        private System.Windows.Forms.Label label8;
        private Guna.UI.WinForms.GunaTextBox txtMedid;
        private Guna.UI.WinForms.GunaButton btnReset;
        private Guna.UI.WinForms.GunaButton btnUpdate;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI.WinForms.GunaDateTimePicker txtMDate;
        private Guna.UI.WinForms.GunaTextBox txtAvaibleQuantity;
        private Guna.UI.WinForms.GunaTextBox txtMedNum;
        private Guna.UI.WinForms.GunaTextBox txtMedName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Guna.UI.WinForms.GunaButton btnSearch;
        private Guna.UI.WinForms.GunaTextBox txtAddQuantity;
        private System.Windows.Forms.Label label9;
        private Guna.UI.WinForms.GunaTextBox txtPricePerUnit;
        private System.Windows.Forms.Label label10;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
    }
}
