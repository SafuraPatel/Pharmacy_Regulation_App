﻿using DGVPrinterHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace pharmacyMS.PharmacistUC
{
    public partial class UC_P_SellMedicine : UserControl
    {
        function fn = new function();
        string query;
        DataSet ds;

        public UC_P_SellMedicine()
        {
            InitializeComponent();
        }

        private string getdate()
        {
            String s = DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year;
            return s;
        }

        private void UC_P_SellMedicine_Load(object sender, EventArgs e)
        {
            listBoxMed.Items.Clear();
            query = "select mname from med where edate <= '2023-03-29' and quantity>'0'";

            ds = fn.geData(query);
            
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBoxMed.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }
        }

        private void btnSync_Click(object sender, EventArgs e)
        {
            UC_P_SellMedicine_Load(this, null);
        }


        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            listBoxMed.Items.Clear();
           /* 
             ***** Query should be ****
             query = "select * from med where mname like '" + txtSearch.Text + "%' and edate >= 'getdate()' and quantity>'0'";
           */

            // but using this
            query = "select mname from med where mname like'" + txtSearch.Text + "%' and edate <= '2023-03-29' and quantity>'0'";

            ds= fn.geData(query);

            for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBoxMed.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }
        }

        private void listBoxMed_SelectedIndexChanged(object sender, EventArgs e) 
        {
            txtNoOfUnits.Clear();

            String name = listBoxMed.GetItemText(listBoxMed.SelectedItem);
            txtMedName.Text = name;
            query = "select mid,parunit from med where mname='"+name+"'";
            ds= fn.geData(query);
            txtMedId.Text = ds.Tables[0].Rows[0][0].ToString();
            txtPricePerUnit.Text=ds.Tables[0].Rows[0][1].ToString();
        }

        private void txtNoOfUnits_TabStopChanged(object sender, EventArgs e) { }
      

        private void txtNoOfUnits_TextChanged(object sender, EventArgs e)
        {
            if(txtNoOfUnits.Text != "")
            {
                Int64 unitPrice = Int64.Parse(txtPricePerUnit.Text);
                Int64 noOfUnit = Int64.Parse(txtNoOfUnits.Text);
                Int64 totalAmount = unitPrice + noOfUnit;

                txtTotalPrice.Text = totalAmount.ToString();
            }
            else
            {
                txtTotalPrice.Clear();
            }
        }


        protected int n, totalAmount = 0;
        protected Int64 quantity, newQuantity;

        private void btnAddToCart_Click(object sender, EventArgs e) 
        {
            if (txtMedId.Text != "")
            {
                query = "select quantity from med where mid = '"+txtMedId.Text+"'";
                ds=fn.geData(query);

                quantity=Int64.Parse(ds.Tables[0].Rows[0][0].ToString());
                newQuantity = quantity - Int64.Parse(txtNoOfUnits.Text);

                if (newQuantity >= 0)
                {
                    n = gunaDataGridView1.Rows.Add();
                    gunaDataGridView1.Rows[n].Cells[0].Value = txtMedId.Text;
                    gunaDataGridView1.Rows[n].Cells[1].Value = txtMedName.Text;
                    gunaDataGridView1.Rows[n].Cells[2].Value = txtPricePerUnit.Text;
                    gunaDataGridView1.Rows[n].Cells[3].Value = txtNoOfUnits.Text;
                    gunaDataGridView1.Rows[n].Cells[4].Value = txtTotalPrice.Text;

                    totalAmount= totalAmount+int.Parse(txtTotalPrice.Text);
                    totalLabel.Text = "Rs. " +totalAmount.ToString();

                    query = "update med set quantity = '"+newQuantity+"' where mid = '"+txtMedId.Text+"'";
                    fn.setData(query, "Medicine Added.");
                }

                else
                {
                    MessageBox.Show("Medicine is out of Stock. \n Only "+quantity+" Left","Warning !!",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }
                clearAlll();
                UC_P_SellMedicine_Load(this,null);
            }
            else
            {
                MessageBox.Show("Select Medicine First.","Information !!", MessageBoxButtons.OK,MessageBoxIcon.Information);
            }     
        }

        int valueAmount;
        String valueId;
        protected Int64 noOfUnit;
        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                valueAmount = int.Parse(gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString());
                valueId = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString(); 
                noOfUnit=Int64.Parse(gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch (Exception)
            {

            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (valueId != null)
            {
                try
                {
                    gunaDataGridView1.Rows.RemoveAt(this.gunaDataGridView1.SelectedRows[0].Index);
                }
                catch { }
                finally 
                {
                    query = "select quantity from med where mid= '"+valueId+"'";
                    ds=fn.geData(query);
                    quantity = Int64.Parse(ds.Tables[0].Rows[0][0].ToString());
                    newQuantity = quantity + noOfUnit;


                    query = "update med set quantity = '" + newQuantity + "' where mid = '" + valueId + "'";
                    fn.setData(query, "Medicine Removed from cart.");
                    totalAmount = totalAmount - valueAmount;
                    totalLabel.Text = "Rs. " + totalAmount.ToString();

                }
                UC_P_SellMedicine_Load(this, null);
            }
        }

        private void txtMedName_TextChanged(object sender, EventArgs e) { }

        private void btnPurches_Click(object sender, EventArgs e)
        {
            DGVPrinter print = new DGVPrinter();
            print.Title = "Medicine Bill";
            print.SubTitle = String.Format("Date:- {0}", DateTime.Now.Date);
            print.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            print.PageNumbers = true;
            print.PageNumberInHeader = true;
            print.PorportionalColumns = true;
            print.HeaderCellAlignment =StringAlignment.Near;
            print.Footer= "Total Payable Amount : " +totalLabel.Text;
            print.FooterSpacing = 15;
            print.PrintDataGridView(gunaDataGridView1);

            totalAmount = 0;
            totalLabel.Text = "Rs. 00";
            gunaDataGridView1.DataSource = 0;
        }

        private void clearAlll()
        {
            txtMedId.Clear();
            txtMedName.Clear();
            txtPricePerUnit.Clear();
            txtNoOfUnits.Clear();
        }
    }
}
