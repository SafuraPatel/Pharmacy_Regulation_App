﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacyMS.PharmacistUC
{
    public partial class UC_P_ViewMedicine : UserControl
    {
        function fn = new function();
        string query;
        
        public UC_P_ViewMedicine()
        {
            InitializeComponent();
        }

        private void UC_P_ViewMedicine_Load(object sender, EventArgs e)
        {
            query = "select * from med";
            setDataGrideView(query);
        }

        private void txtSearchMed_TextChanged(object sender, EventArgs e)
        {
            query = "select * from med where mname like '" + txtSearchMed.Text + "%'";
            DataSet ds = fn.geData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];
        }

        private void setDataGrideView(String query)
        {
            DataSet ds = fn.geData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];
        }


        string medicineId;
        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                medicineId = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
            catch { }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure?", "Delate Confermation !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                query = "delete from med where mid= '" + medicineId + "'";
                fn.setData(query, "Medicine Record Deleted");
                UC_P_ViewMedicine_Load(this, null);
            }
        }

        private void btnSync_Click(object sender, EventArgs e)
        {
            UC_P_ViewMedicine_Load(this, null);
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}
