﻿namespace pharmacyMS.PharmacistUC
{
    partial class UC_P_AddMedicine
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_P_AddMedicine));
            this.label1 = new System.Windows.Forms.Label();
            this.btnReset = new Guna.UI.WinForms.GunaButton();
            this.btnAdd = new Guna.UI.WinForms.GunaButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtManufacturingDate = new Guna.UI.WinForms.GunaDateTimePicker();
            this.txtPricePerUnit = new Guna.UI.WinForms.GunaTextBox();
            this.txtMedNum = new Guna.UI.WinForms.GunaTextBox();
            this.txtMedName = new Guna.UI.WinForms.GunaTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMedid = new Guna.UI.WinForms.GunaTextBox();
            this.txtExpiryDate = new Guna.UI.WinForms.GunaDateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtQantity = new Guna.UI.WinForms.GunaTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Display", 24F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(45, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 58);
            this.label1.TabIndex = 1;
            this.label1.Text = "Add Medicine";
            // 
            // btnReset
            // 
            this.btnReset.AnimationHoverSpeed = 0.07F;
            this.btnReset.AnimationSpeed = 0.03F;
            this.btnReset.BackColor = System.Drawing.Color.Transparent;
            this.btnReset.BaseColor = System.Drawing.Color.MidnightBlue;
            this.btnReset.BorderColor = System.Drawing.Color.Navy;
            this.btnReset.BorderSize = 2;
            this.btnReset.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnReset.FocusedColor = System.Drawing.Color.Empty;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.Image = ((System.Drawing.Image)(resources.GetObject("btnReset.Image")));
            this.btnReset.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnReset.ImageSize = new System.Drawing.Size(20, 20);
            this.btnReset.Location = new System.Drawing.Point(852, 570);
            this.btnReset.Name = "btnReset";
            this.btnReset.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnReset.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.btnReset.OnHoverForeColor = System.Drawing.Color.Navy;
            this.btnReset.OnHoverImage = null;
            this.btnReset.OnPressedColor = System.Drawing.Color.Black;
            this.btnReset.Radius = 10;
            this.btnReset.Size = new System.Drawing.Size(176, 54);
            this.btnReset.TabIndex = 33;
            this.btnReset.Text = "Reset";
            this.btnReset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AnimationHoverSpeed = 0.07F;
            this.btnAdd.AnimationSpeed = 0.03F;
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.BaseColor = System.Drawing.Color.MidnightBlue;
            this.btnAdd.BorderColor = System.Drawing.Color.Navy;
            this.btnAdd.BorderSize = 2;
            this.btnAdd.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAdd.FocusedColor = System.Drawing.Color.Empty;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAdd.ImageSize = new System.Drawing.Size(30, 30);
            this.btnAdd.Location = new System.Drawing.Point(637, 570);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnAdd.OnHoverBorderColor = System.Drawing.Color.Navy;
            this.btnAdd.OnHoverForeColor = System.Drawing.Color.Navy;
            this.btnAdd.OnHoverImage = null;
            this.btnAdd.OnPressedColor = System.Drawing.Color.Black;
            this.btnAdd.Radius = 10;
            this.btnAdd.Size = new System.Drawing.Size(176, 54);
            this.btnAdd.TabIndex = 32;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkBlue;
            this.panel2.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(556, 168);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 638);
            this.panel2.TabIndex = 31;
            // 
            // txtManufacturingDate
            // 
            this.txtManufacturingDate.BackColor = System.Drawing.Color.Transparent;
            this.txtManufacturingDate.BaseColor = System.Drawing.Color.White;
            this.txtManufacturingDate.BorderColor = System.Drawing.Color.Silver;
            this.txtManufacturingDate.CustomFormat = null;
            this.txtManufacturingDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtManufacturingDate.FocusedColor = System.Drawing.Color.Gray;
            this.txtManufacturingDate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtManufacturingDate.ForeColor = System.Drawing.Color.Black;
            this.txtManufacturingDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtManufacturingDate.Location = new System.Drawing.Point(617, 197);
            this.txtManufacturingDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtManufacturingDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtManufacturingDate.Name = "txtManufacturingDate";
            this.txtManufacturingDate.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtManufacturingDate.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.txtManufacturingDate.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtManufacturingDate.OnPressedColor = System.Drawing.Color.Black;
            this.txtManufacturingDate.Radius = 5;
            this.txtManufacturingDate.Size = new System.Drawing.Size(402, 48);
            this.txtManufacturingDate.TabIndex = 30;
            this.txtManufacturingDate.Text = "01-03-2023";
            this.txtManufacturingDate.Value = new System.DateTime(2023, 3, 1, 0, 0, 0, 0);
            // 
            // txtPricePerUnit
            // 
            this.txtPricePerUnit.BackColor = System.Drawing.Color.Transparent;
            this.txtPricePerUnit.BaseColor = System.Drawing.Color.White;
            this.txtPricePerUnit.BorderColor = System.Drawing.Color.Silver;
            this.txtPricePerUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPricePerUnit.FocusedBaseColor = System.Drawing.Color.White;
            this.txtPricePerUnit.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtPricePerUnit.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtPricePerUnit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPricePerUnit.Location = new System.Drawing.Point(617, 449);
            this.txtPricePerUnit.Name = "txtPricePerUnit";
            this.txtPricePerUnit.PasswordChar = '\0';
            this.txtPricePerUnit.Radius = 5;
            this.txtPricePerUnit.SelectedText = "";
            this.txtPricePerUnit.Size = new System.Drawing.Size(402, 48);
            this.txtPricePerUnit.TabIndex = 28;
            // 
            // txtMedNum
            // 
            this.txtMedNum.BackColor = System.Drawing.Color.Transparent;
            this.txtMedNum.BaseColor = System.Drawing.Color.White;
            this.txtMedNum.BorderColor = System.Drawing.Color.Silver;
            this.txtMedNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMedNum.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMedNum.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtMedNum.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedNum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedNum.Location = new System.Drawing.Point(75, 449);
            this.txtMedNum.Name = "txtMedNum";
            this.txtMedNum.PasswordChar = '\0';
            this.txtMedNum.Radius = 5;
            this.txtMedNum.SelectedText = "";
            this.txtMedNum.Size = new System.Drawing.Size(403, 48);
            this.txtMedNum.TabIndex = 27;
            // 
            // txtMedName
            // 
            this.txtMedName.BackColor = System.Drawing.Color.Transparent;
            this.txtMedName.BaseColor = System.Drawing.Color.White;
            this.txtMedName.BorderColor = System.Drawing.Color.Silver;
            this.txtMedName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMedName.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMedName.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtMedName.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedName.Location = new System.Drawing.Point(79, 325);
            this.txtMedName.Name = "txtMedName";
            this.txtMedName.PasswordChar = '\0';
            this.txtMedName.Radius = 5;
            this.txtMedName.SelectedText = "";
            this.txtMedName.Size = new System.Drawing.Size(403, 48);
            this.txtMedName.TabIndex = 26;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(612, 420);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(179, 26);
            this.label6.TabIndex = 23;
            this.label6.Text = "Price Per Unit :-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(72, 420);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 26);
            this.label5.TabIndex = 22;
            this.label5.Text = "Medicine Number :-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(612, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 26);
            this.label4.TabIndex = 21;
            this.label4.Text = "Manufacturing Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(75, 296);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 26);
            this.label3.TabIndex = 20;
            this.label3.Text = "Medicine Name :-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(75, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 26);
            this.label2.TabIndex = 19;
            this.label2.Text = "Medicine ID :-";
            // 
            // txtMedid
            // 
            this.txtMedid.BackColor = System.Drawing.Color.Transparent;
            this.txtMedid.BaseColor = System.Drawing.Color.White;
            this.txtMedid.BorderColor = System.Drawing.Color.Silver;
            this.txtMedid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMedid.FocusedBaseColor = System.Drawing.Color.White;
            this.txtMedid.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtMedid.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtMedid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedid.Location = new System.Drawing.Point(80, 200);
            this.txtMedid.Name = "txtMedid";
            this.txtMedid.PasswordChar = '\0';
            this.txtMedid.Radius = 5;
            this.txtMedid.SelectedText = "";
            this.txtMedid.Size = new System.Drawing.Size(403, 48);
            this.txtMedid.TabIndex = 36;
            // 
            // txtExpiryDate
            // 
            this.txtExpiryDate.BackColor = System.Drawing.Color.Transparent;
            this.txtExpiryDate.BaseColor = System.Drawing.Color.White;
            this.txtExpiryDate.BorderColor = System.Drawing.Color.Silver;
            this.txtExpiryDate.CustomFormat = null;
            this.txtExpiryDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtExpiryDate.FocusedColor = System.Drawing.Color.Gray;
            this.txtExpiryDate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtExpiryDate.ForeColor = System.Drawing.Color.Black;
            this.txtExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtExpiryDate.Location = new System.Drawing.Point(617, 328);
            this.txtExpiryDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtExpiryDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtExpiryDate.Name = "txtExpiryDate";
            this.txtExpiryDate.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtExpiryDate.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.txtExpiryDate.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtExpiryDate.OnPressedColor = System.Drawing.Color.Black;
            this.txtExpiryDate.Radius = 5;
            this.txtExpiryDate.Size = new System.Drawing.Size(402, 48);
            this.txtExpiryDate.TabIndex = 38;
            this.txtExpiryDate.Text = "01-03-2023";
            this.txtExpiryDate.Value = new System.DateTime(2023, 3, 1, 0, 0, 0, 0);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(612, 296);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 26);
            this.label8.TabIndex = 37;
            this.label8.Text = "Expire Date";
            // 
            // txtQantity
            // 
            this.txtQantity.BackColor = System.Drawing.Color.Transparent;
            this.txtQantity.BaseColor = System.Drawing.Color.White;
            this.txtQantity.BorderColor = System.Drawing.Color.Silver;
            this.txtQantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQantity.FocusedBaseColor = System.Drawing.Color.White;
            this.txtQantity.FocusedBorderColor = System.Drawing.Color.Gray;
            this.txtQantity.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtQantity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQantity.Location = new System.Drawing.Point(79, 570);
            this.txtQantity.Name = "txtQantity";
            this.txtQantity.PasswordChar = '\0';
            this.txtQantity.Radius = 5;
            this.txtQantity.SelectedText = "";
            this.txtQantity.Size = new System.Drawing.Size(403, 50);
            this.txtQantity.TabIndex = 40;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Rockwell", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(76, 541);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 26);
            this.label7.TabIndex = 39;
            this.label7.Text = "Quantity :-";
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.TargetControl = this;
            // 
            // UC_P_AddMedicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtQantity);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtExpiryDate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtMedid);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtManufacturingDate);
            this.Controls.Add(this.txtPricePerUnit);
            this.Controls.Add(this.txtMedNum);
            this.Controls.Add(this.txtMedName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UC_P_AddMedicine";
            this.Size = new System.Drawing.Size(1120, 901);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton btnReset;
        private Guna.UI.WinForms.GunaButton btnAdd;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI.WinForms.GunaDateTimePicker txtManufacturingDate;
        private Guna.UI.WinForms.GunaTextBox txtPricePerUnit;
        private Guna.UI.WinForms.GunaTextBox txtMedNum;
        private Guna.UI.WinForms.GunaTextBox txtMedName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Guna.UI.WinForms.GunaTextBox txtMedid;
        private Guna.UI.WinForms.GunaDateTimePicker txtExpiryDate;
        private System.Windows.Forms.Label label8;
        private Guna.UI.WinForms.GunaTextBox txtQantity;
        private System.Windows.Forms.Label label7;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
    }
}
