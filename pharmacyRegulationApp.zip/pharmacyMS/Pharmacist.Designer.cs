﻿namespace pharmacyMS
{
    partial class Pharmacist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pharmacist));
            this.panel2 = new System.Windows.Forms.Panel();
            this.uC_P_SellMedicine1 = new pharmacyMS.PharmacistUC.UC_P_SellMedicine();
            this.uC_P_MedicineValidityCheck1 = new pharmacyMS.PharmacistUC.UC_P_MedicineValidityCheck();
            this.uC_P_UpdateMedicine1 = new pharmacyMS.PharmacistUC.UC_P_UpdateMedicine();
            this.uC_P_ViewMedicine1 = new pharmacyMS.PharmacistUC.UC_P_ViewMedicine();
            this.uC_P_AddMedicine1 = new pharmacyMS.PharmacistUC.UC_P_AddMedicine();
            this.uC_P_Dashboard1 = new pharmacyMS.PharmacistUC.UC_P_Dashboard();
            this.label1 = new System.Windows.Forms.Label();
            this.userNameLable = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnViewMed = new Guna.UI.WinForms.GunaButton();
            this.btnSellMed = new Guna.UI.WinForms.GunaButton();
            this.btnMedValidityCheck = new Guna.UI.WinForms.GunaButton();
            this.btnlogout = new Guna.UI.WinForms.GunaButton();
            this.btnModifyMed = new Guna.UI.WinForms.GunaButton();
            this.btnaddMed = new Guna.UI.WinForms.GunaButton();
            this.btndashboard = new Guna.UI.WinForms.GunaButton();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse2 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse3 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse4 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse5 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse6 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.uC_P_SellMedicine1);
            this.panel2.Controls.Add(this.uC_P_MedicineValidityCheck1);
            this.panel2.Controls.Add(this.uC_P_UpdateMedicine1);
            this.panel2.Controls.Add(this.uC_P_ViewMedicine1);
            this.panel2.Controls.Add(this.uC_P_AddMedicine1);
            this.panel2.Controls.Add(this.uC_P_Dashboard1);
            this.panel2.Location = new System.Drawing.Point(376, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1120, 901);
            this.panel2.TabIndex = 2;
            // 
            // uC_P_SellMedicine1
            // 
            this.uC_P_SellMedicine1.BackColor = System.Drawing.Color.White;
            this.uC_P_SellMedicine1.Location = new System.Drawing.Point(0, 0);
            this.uC_P_SellMedicine1.Name = "uC_P_SellMedicine1";
            this.uC_P_SellMedicine1.Size = new System.Drawing.Size(1120, 901);
            this.uC_P_SellMedicine1.TabIndex = 5;
            // 
            // uC_P_MedicineValidityCheck1
            // 
            this.uC_P_MedicineValidityCheck1.BackColor = System.Drawing.Color.White;
            this.uC_P_MedicineValidityCheck1.Location = new System.Drawing.Point(0, 0);
            this.uC_P_MedicineValidityCheck1.Name = "uC_P_MedicineValidityCheck1";
            this.uC_P_MedicineValidityCheck1.Size = new System.Drawing.Size(1120, 901);
            this.uC_P_MedicineValidityCheck1.TabIndex = 4;
            // 
            // uC_P_UpdateMedicine1
            // 
            this.uC_P_UpdateMedicine1.BackColor = System.Drawing.Color.White;
            this.uC_P_UpdateMedicine1.Location = new System.Drawing.Point(0, 0);
            this.uC_P_UpdateMedicine1.Name = "uC_P_UpdateMedicine1";
            this.uC_P_UpdateMedicine1.Size = new System.Drawing.Size(1120, 901);
            this.uC_P_UpdateMedicine1.TabIndex = 3;
            // 
            // uC_P_ViewMedicine1
            // 
            this.uC_P_ViewMedicine1.BackColor = System.Drawing.Color.White;
            this.uC_P_ViewMedicine1.Location = new System.Drawing.Point(0, 0);
            this.uC_P_ViewMedicine1.Name = "uC_P_ViewMedicine1";
            this.uC_P_ViewMedicine1.Size = new System.Drawing.Size(1120, 901);
            this.uC_P_ViewMedicine1.TabIndex = 2;
            // 
            // uC_P_AddMedicine1
            // 
            this.uC_P_AddMedicine1.BackColor = System.Drawing.Color.White;
            this.uC_P_AddMedicine1.Location = new System.Drawing.Point(0, 0);
            this.uC_P_AddMedicine1.Name = "uC_P_AddMedicine1";
            this.uC_P_AddMedicine1.Size = new System.Drawing.Size(1120, 901);
            this.uC_P_AddMedicine1.TabIndex = 1;
            this.uC_P_AddMedicine1.Load += new System.EventHandler(this.uC_P_AddMedicine1_Load);
            // 
            // uC_P_Dashboard1
            // 
            this.uC_P_Dashboard1.Location = new System.Drawing.Point(0, 0);
            this.uC_P_Dashboard1.Name = "uC_P_Dashboard1";
            this.uC_P_Dashboard1.Size = new System.Drawing.Size(1120, 901);
            this.uC_P_Dashboard1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(89, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pharmacist";
            // 
            // userNameLable
            // 
            this.userNameLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameLable.ForeColor = System.Drawing.Color.Navy;
            this.userNameLable.Location = new System.Drawing.Point(-3, 831);
            this.userNameLable.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userNameLable.Name = "userNameLable";
            this.userNameLable.Size = new System.Drawing.Size(378, 54);
            this.userNameLable.TabIndex = 9;
            this.userNameLable.Text = "SS Health Care";
            this.userNameLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(46, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(280, 224);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.btnViewMed);
            this.panel1.Controls.Add(this.btnSellMed);
            this.panel1.Controls.Add(this.btnMedValidityCheck);
            this.panel1.Controls.Add(this.btnlogout);
            this.panel1.Controls.Add(this.btnModifyMed);
            this.panel1.Controls.Add(this.btnaddMed);
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.userNameLable);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(372, 903);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnViewMed
            // 
            this.btnViewMed.AnimationHoverSpeed = 0.07F;
            this.btnViewMed.AnimationSpeed = 0.03F;
            this.btnViewMed.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btnViewMed.BorderColor = System.Drawing.Color.Black;
            this.btnViewMed.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnViewMed.FocusedColor = System.Drawing.Color.Empty;
            this.btnViewMed.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewMed.ForeColor = System.Drawing.Color.White;
            this.btnViewMed.Image = ((System.Drawing.Image)(resources.GetObject("btnViewMed.Image")));
            this.btnViewMed.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnViewMed.ImageSize = new System.Drawing.Size(30, 30);
            this.btnViewMed.Location = new System.Drawing.Point(-56, 457);
            this.btnViewMed.Name = "btnViewMed";
            this.btnViewMed.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnViewMed.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnViewMed.OnHoverForeColor = System.Drawing.Color.RoyalBlue;
            this.btnViewMed.OnHoverImage = null;
            this.btnViewMed.OnPressedColor = System.Drawing.Color.Black;
            this.btnViewMed.Size = new System.Drawing.Size(463, 42);
            this.btnViewMed.TabIndex = 19;
            this.btnViewMed.Text = "View Medicine";
            this.btnViewMed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnViewMed.Click += new System.EventHandler(this.btnViewMed_Click_1);
            // 
            // btnSellMed
            // 
            this.btnSellMed.AnimationHoverSpeed = 0.07F;
            this.btnSellMed.AnimationSpeed = 0.03F;
            this.btnSellMed.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btnSellMed.BorderColor = System.Drawing.Color.Black;
            this.btnSellMed.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSellMed.FocusedColor = System.Drawing.Color.Empty;
            this.btnSellMed.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSellMed.ForeColor = System.Drawing.Color.White;
            this.btnSellMed.Image = ((System.Drawing.Image)(resources.GetObject("btnSellMed.Image")));
            this.btnSellMed.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSellMed.ImageSize = new System.Drawing.Size(50, 50);
            this.btnSellMed.Location = new System.Drawing.Point(-53, 668);
            this.btnSellMed.Name = "btnSellMed";
            this.btnSellMed.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnSellMed.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnSellMed.OnHoverForeColor = System.Drawing.Color.RoyalBlue;
            this.btnSellMed.OnHoverImage = null;
            this.btnSellMed.OnPressedColor = System.Drawing.Color.Black;
            this.btnSellMed.Size = new System.Drawing.Size(453, 42);
            this.btnSellMed.TabIndex = 18;
            this.btnSellMed.Text = "Sell Medicine";
            this.btnSellMed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSellMed.Click += new System.EventHandler(this.btnSellMed_Click_1);
            // 
            // btnMedValidityCheck
            // 
            this.btnMedValidityCheck.AnimationHoverSpeed = 0.07F;
            this.btnMedValidityCheck.AnimationSpeed = 0.03F;
            this.btnMedValidityCheck.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btnMedValidityCheck.BorderColor = System.Drawing.Color.Black;
            this.btnMedValidityCheck.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnMedValidityCheck.FocusedColor = System.Drawing.Color.Empty;
            this.btnMedValidityCheck.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedValidityCheck.ForeColor = System.Drawing.Color.White;
            this.btnMedValidityCheck.Image = ((System.Drawing.Image)(resources.GetObject("btnMedValidityCheck.Image")));
            this.btnMedValidityCheck.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMedValidityCheck.ImageSize = new System.Drawing.Size(30, 30);
            this.btnMedValidityCheck.Location = new System.Drawing.Point(-50, 600);
            this.btnMedValidityCheck.Name = "btnMedValidityCheck";
            this.btnMedValidityCheck.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnMedValidityCheck.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnMedValidityCheck.OnHoverForeColor = System.Drawing.Color.RoyalBlue;
            this.btnMedValidityCheck.OnHoverImage = null;
            this.btnMedValidityCheck.OnPressedColor = System.Drawing.Color.Black;
            this.btnMedValidityCheck.Size = new System.Drawing.Size(453, 42);
            this.btnMedValidityCheck.TabIndex = 17;
            this.btnMedValidityCheck.Text = "Medicine Validity Check";
            this.btnMedValidityCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMedValidityCheck.Click += new System.EventHandler(this.btnMedValidityCheck_Click_1);
            // 
            // btnlogout
            // 
            this.btnlogout.AnimationHoverSpeed = 0.07F;
            this.btnlogout.AnimationSpeed = 0.03F;
            this.btnlogout.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btnlogout.BorderColor = System.Drawing.Color.Black;
            this.btnlogout.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnlogout.FocusedColor = System.Drawing.Color.Empty;
            this.btnlogout.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.White;
            this.btnlogout.Image = ((System.Drawing.Image)(resources.GetObject("btnlogout.Image")));
            this.btnlogout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnlogout.ImageSize = new System.Drawing.Size(30, 30);
            this.btnlogout.Location = new System.Drawing.Point(-53, 732);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnlogout.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnlogout.OnHoverForeColor = System.Drawing.Color.Red;
            this.btnlogout.OnHoverImage = null;
            this.btnlogout.OnPressedColor = System.Drawing.Color.Black;
            this.btnlogout.Size = new System.Drawing.Size(453, 42);
            this.btnlogout.TabIndex = 16;
            this.btnlogout.Text = "Logout";
            this.btnlogout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click_1);
            // 
            // btnModifyMed
            // 
            this.btnModifyMed.AnimationHoverSpeed = 0.07F;
            this.btnModifyMed.AnimationSpeed = 0.03F;
            this.btnModifyMed.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btnModifyMed.BorderColor = System.Drawing.Color.Black;
            this.btnModifyMed.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnModifyMed.FocusedColor = System.Drawing.Color.Empty;
            this.btnModifyMed.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModifyMed.ForeColor = System.Drawing.Color.White;
            this.btnModifyMed.Image = ((System.Drawing.Image)(resources.GetObject("btnModifyMed.Image")));
            this.btnModifyMed.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnModifyMed.ImageSize = new System.Drawing.Size(30, 30);
            this.btnModifyMed.Location = new System.Drawing.Point(-50, 531);
            this.btnModifyMed.Name = "btnModifyMed";
            this.btnModifyMed.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnModifyMed.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnModifyMed.OnHoverForeColor = System.Drawing.Color.RoyalBlue;
            this.btnModifyMed.OnHoverImage = null;
            this.btnModifyMed.OnPressedColor = System.Drawing.Color.Black;
            this.btnModifyMed.Size = new System.Drawing.Size(453, 42);
            this.btnModifyMed.TabIndex = 15;
            this.btnModifyMed.Text = "Modify Medicine";
            this.btnModifyMed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnModifyMed.Click += new System.EventHandler(this.btnModifyMed_Click_1);
            // 
            // btnaddMed
            // 
            this.btnaddMed.AnimationHoverSpeed = 0.07F;
            this.btnaddMed.AnimationSpeed = 0.03F;
            this.btnaddMed.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btnaddMed.BorderColor = System.Drawing.Color.Black;
            this.btnaddMed.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnaddMed.FocusedColor = System.Drawing.Color.Empty;
            this.btnaddMed.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddMed.ForeColor = System.Drawing.Color.White;
            this.btnaddMed.Image = ((System.Drawing.Image)(resources.GetObject("btnaddMed.Image")));
            this.btnaddMed.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnaddMed.ImageSize = new System.Drawing.Size(30, 30);
            this.btnaddMed.Location = new System.Drawing.Point(-53, 384);
            this.btnaddMed.Name = "btnaddMed";
            this.btnaddMed.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnaddMed.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnaddMed.OnHoverForeColor = System.Drawing.Color.RoyalBlue;
            this.btnaddMed.OnHoverImage = null;
            this.btnaddMed.OnPressedColor = System.Drawing.Color.Black;
            this.btnaddMed.Size = new System.Drawing.Size(463, 42);
            this.btnaddMed.TabIndex = 14;
            this.btnaddMed.Text = "Add Medicine";
            this.btnaddMed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnaddMed.Click += new System.EventHandler(this.btnaddMed_Click_1);
            // 
            // btndashboard
            // 
            this.btndashboard.AnimationHoverSpeed = 0.07F;
            this.btndashboard.AnimationSpeed = 0.03F;
            this.btndashboard.BaseColor = System.Drawing.Color.RoyalBlue;
            this.btndashboard.BorderColor = System.Drawing.Color.Black;
            this.btndashboard.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btndashboard.FocusedColor = System.Drawing.Color.Empty;
            this.btndashboard.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.ForeColor = System.Drawing.Color.White;
            this.btndashboard.Image = ((System.Drawing.Image)(resources.GetObject("btndashboard.Image")));
            this.btndashboard.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btndashboard.ImageSize = new System.Drawing.Size(30, 30);
            this.btndashboard.Location = new System.Drawing.Point(-56, 311);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.OnHoverBaseColor = System.Drawing.Color.White;
            this.btndashboard.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btndashboard.OnHoverForeColor = System.Drawing.Color.RoyalBlue;
            this.btndashboard.OnHoverImage = null;
            this.btndashboard.OnPressedColor = System.Drawing.Color.Black;
            this.btndashboard.Size = new System.Drawing.Size(453, 42);
            this.btndashboard.TabIndex = 13;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.TargetControl = this.panel2;
            // 
            // gunaElipse2
            // 
            this.gunaElipse2.TargetControl = this.panel2;
            // 
            // gunaElipse3
            // 
            this.gunaElipse3.TargetControl = this.panel2;
            // 
            // gunaElipse4
            // 
            this.gunaElipse4.TargetControl = this.panel2;
            // 
            // gunaElipse5
            // 
            this.gunaElipse5.TargetControl = this.panel2;
            // 
            // gunaElipse6
            // 
            this.gunaElipse6.TargetControl = this.panel2;
            // 
            // Pharmacist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1496, 904);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Pharmacist";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pharmacist";
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label userNameLable;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton btnViewMed;
        private Guna.UI.WinForms.GunaButton btnSellMed;
        private Guna.UI.WinForms.GunaButton btnMedValidityCheck;
        private Guna.UI.WinForms.GunaButton btnlogout;
        private Guna.UI.WinForms.GunaButton btnModifyMed;
        private Guna.UI.WinForms.GunaButton btnaddMed;
        private Guna.UI.WinForms.GunaButton btndashboard;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private PharmacistUC.UC_P_Dashboard uC_P_Dashboard1;
        private Guna.UI.WinForms.GunaElipse gunaElipse2;
        private PharmacistUC.UC_P_AddMedicine uC_P_AddMedicine1;
        private Guna.UI.WinForms.GunaElipse gunaElipse3;
        private PharmacistUC.UC_P_ViewMedicine uC_P_ViewMedicine1;
        private Guna.UI.WinForms.GunaElipse gunaElipse4;
        private PharmacistUC.UC_P_UpdateMedicine uC_P_UpdateMedicine1;
        private Guna.UI.WinForms.GunaElipse gunaElipse5;
        private PharmacistUC.UC_P_MedicineValidityCheck uC_P_MedicineValidityCheck1;
        private Guna.UI.WinForms.GunaElipse gunaElipse6;
        private PharmacistUC.UC_P_SellMedicine uC_P_SellMedicine1;
    }
}